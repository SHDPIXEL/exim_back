const mongoose = require('mongoose');

// News Schema
const NewsSchema = mongoose.Schema({
  category_id:{
    type: String,
    required: true
  },
  date:{
    type: Date,
    required: true
  },
  headline:{
    type: String,
    required: true
  },
  breaking_news:{
    type: String
  },
  description:{
    type: String,
    required: true
  },
  four_lines:{
    type: String
  },
  image:{
    type: String
  },
  sql_id:{
    type: String
  }
}, {timestamps: true});

const News = module.exports = mongoose.model('News', NewsSchema);
